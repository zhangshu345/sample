var r = http.get("https://www.baidu.com");
log(r)